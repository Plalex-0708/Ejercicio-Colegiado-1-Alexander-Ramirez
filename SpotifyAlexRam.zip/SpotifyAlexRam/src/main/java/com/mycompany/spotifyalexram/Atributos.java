package com.mycompany.spotifyalexram;

public class Atributos {

    public String IDcancion;
    public String Titulo;
    public String Autor;
    public String Duracion;
    public int Acreacion;

    public Atributos(String IDcancion, String Titulo, String Autor, String Duracion, int Acreacion) {
        this.IDcancion = IDcancion;
        this.Titulo = Titulo;
        this.Autor = Autor;
        this.Duracion = Duracion;
        this.Acreacion = Acreacion;
    }

    public String getIDcancion() {
        return IDcancion;
    }

    public void setIDcancion(String IDcancion) {
        this.IDcancion = IDcancion;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String Titulo) {
        this.Titulo = Titulo;
    }

    public String getAutor() {
        return Autor;
    }

    public void setAutor(String Autor) {
        this.Autor = Autor;
    }

    public String getDuracion() {
        return Duracion;
    }

    public void setDuracion(String Duracion) {
        this.Duracion = Duracion;
    }

    public int getAcreacion() {
        return Acreacion;
    }

    public void setAcreacion(int Acreacion) {
        this.Acreacion = Acreacion;
    }

}
