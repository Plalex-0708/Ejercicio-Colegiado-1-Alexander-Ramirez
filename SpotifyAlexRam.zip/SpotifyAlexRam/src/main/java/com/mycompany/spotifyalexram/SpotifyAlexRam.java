package com.mycompany.spotifyalexram;

public class SpotifyAlexRam {

    public static void main(String[] args) {

        Atributos A1 = new Atributos("Dl5768", "Dream on", "Aerosmith", "4:28", 1973);

        A1.setIDcancion("as1234");
        A1.setTitulo("Aserca");
        A1.setAutor("Alex");
        A1.setDuracion("12;34");
        A1.setAcreacion(1234);

        System.out.println("Datos de la cancion" + "id" + A1.getIDcancion() + "Titulo" + A1.getTitulo() + "Autor" + A1.getAutor()
                + "Duracion" + A1.getDuracion() + "Ano de creacion" + A1.getAcreacion());
    }
}
